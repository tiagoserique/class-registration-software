# trabalho-paradigmas

Feito por:
- Iago Mello Floriano
- Luan Machado Bernardt
- Arthur Henrique Canello Vilar
- Tiago Serique Valadares


## Objetivos:

    * Auxiliar o aluno no seu pedido de quebra de barreira
    * verificar a situação do aluno
    * gerar um arquivo texto com o pedido de quebra e seus dados

## Funções do sistema

* O sistema deve permitir que o aluno obtenha as suas informações do histórico importando um arquivo .CSV.

* O sistema devera importar dados sobre as disciplinas, sua disponibilidade no semestre e a grade curricular, tambem de arquivo .CSV

* O sistema devera colocar estes dados em uma lista com as materias cursadas e uma lista das materias do curso

* O sistema devera entao apresentar uma tabela com as materias cursadas por perıodo e as materias que faltam cursar para a barreira

* o sistema devera apresentar os dados de aprovacao do ultimo perıodo como porcentagem de aprovacao e quantas materias reprovou por falta

* O sistema devera mostra ao aluno o conjunto de disciplinas ofertadas neste semestre que nao foram cursadas neste semestre por ordem de perıodo

* O sistema devera possibilitar que o aluno selecione um conjunto de disciplinas que ele deseja cursar com informacao sobre a prioridade delas

* O sistema devera calcular o numero de disciplinas sugerido pelas regras aprovadas em colegiado e mostrar este resultado.

* O sistema deve permitir salvar os dados do pedido em um arquivo de forma a permitir que o aluno os edite posteriormente

* Quando o aluno selecionar enviar, o sistema devera gerar um arquivo texto contendo os dados do pedido.

# Pra compilar 

```shell
./compilaTudo.sh
```

# Para rodar

```shell
cd controller
make run
```
