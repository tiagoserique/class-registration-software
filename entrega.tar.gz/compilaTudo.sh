#!/bin/bash

make -C materia
make -C model
make -C view
make -C controller
