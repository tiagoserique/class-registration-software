package view;

public interface TelaSub{

  public void update(Tela updated);

}
