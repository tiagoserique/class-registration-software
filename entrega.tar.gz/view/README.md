# View

## TelaInicial

- [X] Importar matérias.

## TelaEstado

- [X] Mostrar matérias cursadas por período.
- [X] Mostrar matérias que faltam cursar para barreira.
- [X] Mostrar dados de aprovação do último período (% de aprovação e quantas matérias reprovou por falta).

## TelaSolicitar

- [X] Mostrar matérias ofertadas neste semestre que não foram cursadas, por ordem de período.
- [X] Permitir selecionar matérias que quer cursar com ordem de prioridade.
- [X] Permitir enviar matérias selecionadas para fazer pedido.
